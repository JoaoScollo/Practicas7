// Elementos del DOM
const calorieCounter = document.getElementById('calorie-counter');
const budgetNumberInput = document.getElementById('budget');
const entryDropdown = document.getElementById('entry-dropdown');
const addEntryButton = document.getElementById('add-entry');
const clearButton = document.getElementById('clear');
const output = document.getElementById('output');

// Estado
let isError = false;

// Función para limpiar entradas
function cleanInputString(str) {
  const regex = /[+-\s]/g;
  return str.replace(regex, '');
}

// Verificar entradas inválidas
function isInvalidInput(str) {
  const regex = /\d+e\d+/i;
  return str.match(regex);
}

// Función para agregar entrada
function addEntry() {
  const targetInputContainer = document.querySelector(`#${entryDropdown.value} .input-container`);
  const entryNumber = targetInputContainer.querySelectorAll('input[type="text"]').length + 1;

  const HTMLString = `
    <label for="${entryDropdown.value}-${entryNumber}-name">Entrada ${entryNumber} Nombre</label>
    <input type="text" id="${entryDropdown.value}-${entryNumber}-name" placeholder="Nombre" />
    <label for="${entryDropdown.value}-${entryNumber}-calories">Entrada ${entryNumber} Calorías</label>
    <input
      type="number"
      id="${entryDropdown.value}-${entryNumber}-calories"
      placeholder="Calorías"
      min="0"
    />
  `;

  targetInputContainer.insertAdjacentHTML('beforeend', HTMLString);
}

// Obtener calorías de entradas
function getCaloriesFromInputs(list) {
  let calories = 0;
  for (const item of list) {
    const currVal = cleanInputString(item.value);
    const invalidInputMatch = isInvalidInput(currVal);

    if (invalidInputMatch) {
      alert(`Entrada inválida: ${invalidInputMatch[0]}`);
      isError = true;
      return null;
    }
    calories += Number(currVal);
  }
  return calories;
}

// Función para calcular calorías
function calculateCalories(e) {
  e.preventDefault();
  isError = false;

  const breakfastCalories = getCaloriesFromInputs(document.querySelectorAll('#breakfast input[type="number"]'));
  const lunchCalories = getCaloriesFromInputs(document.querySelectorAll('#lunch input[type="number"]'));
  const dinnerCalories = getCaloriesFromInputs(document.querySelectorAll('#dinner input[type="number"]'));
  const snacksCalories = getCaloriesFromInputs(document.querySelectorAll('#snacks input[type="number"]'));
  const exerciseCalories = getCaloriesFromInputs(document.querySelectorAll('#exercise input[type="number"]'));
  const budgetCalories = Number(budgetNumberInput.value);

  if (isError) return;

  const consumedCalories = breakfastCalories + lunchCalories + dinnerCalories + snacksCalories;
  const remainingCalories = budgetCalories - consumedCalories + exerciseCalories;
  const surplusOrDeficit = remainingCalories < 0 ? 'Superávit' : 'Déficit';

  output.innerHTML = `
    <span class="${surplusOrDeficit.toLowerCase()}">${Math.abs(remainingCalories)} Calorías ${surplusOrDeficit}</span>
    <hr>
    <p>${budgetCalories} Calorías Presupuestadas</p>
    <p>${consumedCalories} Calorías Consumidas</p>
    <p>${exerciseCalories} Calorías Quemadas</p>
  `;
  output.classList.remove('hide');
}

// Función para limpiar formulario
function clearForm() {
  document.querySelectorAll('.input-container').forEach(container => (container.innerHTML = ''));
  budgetNumberInput.value = '';
  output.innerHTML = '';
  output.classList.add('hide');
}

// Eventos
addEntryButton.addEventListener('click', addEntry);
calorieCounter.addEventListener('submit', calculateCalories);
clearButton.addEventListener('click', clearForm);
